
const allMenuList = {
  top: [
    {
      name: "Kullanıcı Yönetimi",
      icon: "Users",
      permission: "USER_MENU_PERMISSION",
    },
    {
      name: "Ham Ürün Yönetimi",
      icon: "Layers",
      permission: "RAWPRODUCT_MENU_PERMISSION",
    },
    {
      name: "Üretim Yönetimi",
      icon: "Layers",
      permission: "PRODUCT_MENU_PERMISSION",
    }
  ],
  bottom: [
  ]
};

 export default allMenuList;